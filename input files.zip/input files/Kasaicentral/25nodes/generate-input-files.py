import copy
import json

import pandas as pd
from input_file_generation.ClimateGenerator import ClimateGenerator
from input_file_generation.DemographicsGenerator import DemographicsGenerator
from simtools.SetupParser import SetupParser


def generate_demographics(csv_fname, demog_file) :

    DemographicsGenerator.from_grid_file(csv_fname, demog_file, res_in_arcsec=30)

    with open(demog_file) as fin :
        demog = json.loads(fin.read())

    node_list = demog['Nodes']
    demog['Metadata']['IdReference'] = 'Gridded world grump30arcsec'
    with open(demog_file, 'w') as fout:
        json.dump(demog, fout, indent=4, sort_keys=True, separators=(',', ': '))

    node_id_list = [x['NodeID'] for x in node_list]
    df = pd.read_csv(csv_fname)
    df['new_nodeid'] = pd.Series(node_id_list)
    df.to_csv(csv_fname, index=False)

    for i, node in enumerate(node_list):
        single_node_demog = copy.deepcopy(demog)
        del node['NodeAttributes']['LarvalHabitatMultiplier']
        node['NodeID'] = 1535977513
        single_node_demog['Nodes'] = [node]

        with open('Kasaicentral_node%d.json' % (i+1), 'w') as fout :
            json.dump(single_node_demog, fout, indent=4, sort_keys=True, separators=(',', ': '))



if __name__ == '__main__' :
    SetupParser.init("HPC")
    fname = 'Kasaicentral-25nodes-input.csv'
    demog_file = 'Kasaicentral_node13.json'
    generate_demographics(fname, demog_file)
    clim = ClimateGenerator(demog_file, './temp.json', './', start_year="2001", climate_project='IDM-Democratic_Republic_of_the_Congo')
    clim.generate_climate_files()
